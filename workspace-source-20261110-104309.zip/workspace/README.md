# 1602fb2f-3641-495b-a6a4-28b3c0c1d4e0-78934d1e-4bc7-43c2-97f3-044aabb83d35
https://sonar.server.examly.io/dashboard?id=iamneo-production-2_1602fb2f-3641-495b-a6a4-28b3c0c1d4e0-78934d1e-4bc7-43c2-97f3-044aabb83d35&amp;codeScope=overall
